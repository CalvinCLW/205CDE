<!-- Header -->
<div class="header">
    <div class="navbar" id='nav'>
        <ul id="navword">
            <li><img src="img/icon/logo.png"></li>
            <li><a href="homepage.php">Home</a></li>
            <li><a href="aboutus.php">About Us</a></li>
            <li><a href="aboutcoffee.php">About Coffee</a></li>
            <li><a href="reservation.php">Reservation</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
        </ul>
    </div>
</div>
<!-- End of header -->  