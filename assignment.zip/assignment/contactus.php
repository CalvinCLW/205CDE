<html>
<head>
<?php require ('link.php'); ?>
</head>
<body>
<?php require ('header.php'); ?>
    
<!-- Content -->

<div class="contactus">
    
<!-- Banner -->
<img src="img/banner/contactusbanner.jpg" class="banner"> 
<!-- End of Banner -->

<div class="container main-content firstrow">
    <div class="row contactusrow">
        <div class="col-6" data-aos="fade-right">
            <img src="img/contactusform.jpg">
        </div>
        <div class="col-6" data-aos="fade-left">
            <h1>Contact Us</h1>
            <form name="contactForm" action="#" method="post" onsubmit="return submit_onClick(this);">
                <input type="text" name="name" placeholder="Enter Your Name" onblur="name_onBlur()" required>
                <br>
                <select name="type">
                    <option>Select Type</option>
                    <option>Reservation</option>
                    <option>Feedback</option>
                    <option>Information</option>
                </select>
                <br>
                <input type="email" name="email" placeholder="Enter Your E-mail" onblur="email_onBlur()" required>
                <br>
                <input type="number" name="phone" placeholder="Enter Your Phone Number" onblur="phone_onBlur()" required>
                <br>
                <textarea name="message" placeholder="Enter Your Message" onblur="message_onBlur()" required></textarea>
                <br>
                <input type="submit" name="submit" value="Send">
            </form>
        </div>
    </div>
</div>

    
</div>    

<!-- End of Content-->

    
<!-- Javascript Validation -->
<script type="text/javascript">
		function submit_onClick(){
			var myForm = document.contactForm;
			
			if(myForm.name.value == "" || myForm.email.value == "" || myForm.phone.value == "" || myForm.message.value == ""){
				alert("Please complete the form!");
				if(myForm.name.value == ""){
					myForm.name.focus();
				}
                else if(myForm.email.value == ""){
					myForm.email.focus();
				}
                else if(myForm.phone.value == ""){
					myForm.phone.focus();
				}
                else if(myForm.message.value == ""){
					myForm.message.focus();
				}
			}
            
            else{
				alert("Form Succesfully Submitted!");
                
                location.reload();
			}
		}
		
		function name_onBlur(){
			var name = document.contactForm.name;
			
			if(isNaN(name.value) == false){
				alert("Please enter a valid name!");
			}
		}
		
		function email_onBlur(){
			var email = document.contactForm.email;
			
			if(isNaN(email.value) == false){
				alert("Please enter email!");
			}
		}
    
        function phone_onBlur(){
			var phone = document.contactForm.phone;
			
			if(phone.value == ""){
				alert("Please enter phone!");
			}
		}
    
        function message_onBlur(){
			var message = document.contactForm.message;
			
			if(isNaN(message.value) == false){
				alert("Please enter message!");
			}
		}
</script>   
<!-- End of Javascript Validation -->
<!-- Footer -->
<?php require('footer.php'); ?>
<!-- Javascript -->
<?php require('javascript.php'); ?>
</body>
</html>